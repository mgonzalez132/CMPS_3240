#include <stdio.h>
#include <stdlib.h>
#include "myblas.h"

#define SIZE 2000000000

int main( void ) {
  
    float *x = (float *) malloc(SIZE * sizeof(float) );
    float *y = (float *) malloc(SIZE * sizeof(float) );
    float *result = (float *) malloc(SIZE * sizeof(float) );
    printf ( "Benchmark FAXPY operation on array size %d x 1\n", SIZE);

    faxpyu(SIZE, 1.0, x, y, result);
    free(x);
    free(y);  
    free(result);
    return 0;
}


